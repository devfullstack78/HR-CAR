<footer class="bg-dark text-white text-center py-3">
    <p>© 2024 HR CAR LOCATION - Tous droits réservés.</p>
</footer>